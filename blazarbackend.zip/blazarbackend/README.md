To run the project with docker, run `docker compose up -d` command inside the root folder.
